import os
from flask import *
from src.dbconnection import *
from werkzeug.utils import secure_filename
app=Flask(__name__)

app.secret_key='qq'

@app.route('/')
def log():
    return render_template("loginindex.html")

@app.route('/login',methods=['post'])
def login():

  uname=request.form['textfield']
  paaword=request.form['textfield2']
  qry="SELECT * FROM `login` WHERE `username`=%s AND `password`=%s"
  val=(uname,paaword)
  res=selectone(qry,val)
  if res is None:
      return '''<script>alert("INVALID USER");window.location="/"</script>'''
  elif res['type']=='admin':
      session['lid'] = res['login_id']
      return '''<script>alert("SUCESSFULLY LOGIN");window.location="admin_home"</script>'''
  elif res['type']=='expert':
      session['lid'] = res['login_id']
      return '''<script>alert("SUCESSFULLY LOGIN");window.location="expert_home"</script>'''
  elif res['type']=='user':
      session['lid']=res['login_id']
      return '''<script>alert("SUCESSFULLY LOGIN");window.location="user_home"</script>'''
  else:
      return '''<script>alert("THIS USER NO LONGER AVAILABLE");window.location="/"</script>'''

#======================================ADMIN======================

@app.route('/admin_home')
def admin_home():
    return render_template('admin/home.html')

@app.route('/viewexpert')
def viewexpert():
    q="select * from expert"
    res=selectall(q)
    print(res)
    return render_template("admin/view_expert.html",data=res)

@app.route('/addexpert')
def addexpert():
    return render_template("admin/add_expert.html")

@app.route('/addexpert1',methods=['post'])
def addexpert1():
    fname=request.form['textfield']
    lname=request.form['textfield2']
    place = request.form['textfield3']
    post = request.form['textfield4']
    pin = request.form['textfield5']
    phone = request.form['textfield6']
    email = request.form['textfield7']
    qlf=request.form['textfield8']
    img=request.files['file']
    filename=secure_filename(img.filename)
    img.save(os.path.join('static/images',filename))
    uname = request.form['textfield10']
    pword = request.form['textfield11']

    qry="INSERT INTO `login` VALUES (NULL,%s,%s,'expert')"
    val=(uname,pword)
    res=iud(qry,val)


    q="INSERT INTO `expert`VALUES (NULL,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    val1=(str(res),fname,lname,place,post,pin,phone,email,qlf,filename)
    iud(q,val1)
    return '''<script>alert("Sucessfully Added");window.location="/addexpert"</script>'''

@app.route('/editexpert')
def editexpert():
    id=request.args.get('id')
    session['eid']=id
    qry="SELECT*FROM `expert`WHERE`eid`=%s"
    res=selectone(qry,id)
    return render_template("admin/edit_expert.html",val=res)

@app.route('/updateexpert', methods=['post'])
def updateexpert():
    try:
        fname = request.form['textfield']
        lname = request.form['textfield2']
        place = request.form['textfield3']
        post = request.form['textfield4']
        pin = request.form['textfield5']
        phone = request.form['textfield6']
        email = request.form['textfield7']
        qlf = request.form['textfield8']
        img = request.files['file']
        filename = secure_filename(img.filename)
        img.save(os.path.join('static/images',filename))
        qry="UPDATE `expert` SET `firstname`=%s,`lastname`=%s,`place`=%s,`post`=%s,`pin`=%s,`phone`=%s,`email`=%s,`qualification`=%s,`image`=%s WHERE eid=%s"
        val=(fname,lname,place,post,pin,phone,email,qlf,filename,session['eid'])
        iud(qry,val)
        return '''<script>alert("UPDATED");window.location="/viewexpert"</script>'''
    except Exception as e:
        fname = request.form['textfield']
        lname = request.form['textfield2']
        place = request.form['textfield3']
        post = request.form['textfield4']
        pin = request.form['textfield5']
        phone = request.form['textfield6']
        email = request.form['textfield7']
        qlf = request.form['textfield8']

        qry = "UPDATE `expert` SET `firstname`=%s,`lastname`=%s,`place`=%s,`post`=%s,`pin`=%s,`phone`=%s,`email`=%s,`qualification`=%s WHERE eid=%s"
        val = (fname, lname, place, post, pin, phone, email, qlf, session['eid'])
        iud(qry, val)
        return '''<script>alert("UPDATED");window.location="/viewexpert"</script>'''





@app.route('/deleteexpert')
def deleteexpert():
    id=request.args.get('id')
    q="DELETE FROM `expert` WHERE `lid`=%s"
    v=(id)
    iud(q,v)
    qry="DELETE FROM`login`WHERE`login_id`=%s"
    val=(id)
    iud(qry,val)
    return '''<script>alert("DELETED");window.location="/viewexpert"</script>'''



@app.route('/blockunblock')
def blockunblock():
    qry="SELECT `user`.*,`login`.* FROM`login`JOIN `user`ON `user`.`lid`=`login_id`"
    res=selectall(qry)
    return render_template("admin/block_unblock.html",data=res)

@app.route('/replycomplaint')
def replycomplaint():
    id=request.args.get('id')
    session['cid']=id
    return render_template("admin/reply_complaint.html")

@app.route('/rply',methods=['post'])
def rply():
    reply=request.form['textarea']
    qry="UPDATE `complaint` SET `reply`=%s WHERE `cid`=%s"
    iud(qry,(reply, session['cid']))
    return '''<script>alert("replied");window.location="/viewcomplaint"</script>'''


@app.route('/sendnotification')
def sendnotification():
    return render_template("admin/send_notification.html")

@app.route('/send1',methods=['post'])
def send1():
    notfn=request.form['textarea']
    q="INSERT INTO `notification` VALUES (NULL,%s,CURDATE())"
    val=(notfn)
    iud(q,val)
    return '''<script>alert("SUCESSFULLY SEND");window.location="/viewnotifications"</script>'''

@app.route('/deletentfctn')
def deletentfctn():
    id=request.args.get('id')
    qry="DELETE FROM `notification`WHERE`nid`=%s"
    v=(id)
    iud(qry,v)
    return '''<script>alert("DELETED");window.location="/viewnotifications"</script>'''






@app.route('/viewcomplaint')
def viewcomplaint():
    qry="SELECT `user`.`firstname`,`lastname` ,`complaint`.* FROM `complaint` JOIN `user` ON `complaint`.`lid`=`user`.`lid`"
    res=selectall(qry)

    return render_template("admin/view_complaint.html",val=res)



@app.route('/viewnotifications')
def viewnotifications():
    qry="SELECT*FROM `notification`"
    res=selectall(qry)

    return render_template("admin/view_notifications.html", data=res)



#================================EXPERT===================================
@app.route('/addtips')
def addtips():
    qry="SELECT*FROM `tips` where eid=%s"
    res=selectall2(qry,session['lid'])
    return render_template("expert/add_tips.html", val=res)

@app.route('/deletetips')
def deletetips():
    id=request.args.get('id')
    q="DELETE FROM `tips` WHERE `tid`=%s"
    v=(id)
    iud(q,v)
    return '''<script>alert("DELETED");window.location="/addtips"</script>'''

@app.route('/vnotfcn')
def vnotfcn():
    qry="select*from `notification`"
    res=selectall(qry)

    return render_template("expert/view_notifications.html",data=res)


@app.route('/expert_home')
def expert_home():
    return render_template("expert/home.html")

@app.route('/replydoubt1')
def replydoubt1():
    id = request.args.get('id')
    print(id,"llllllllllllll")
    session['did'] = id
    return render_template("expert/reply_doubt.html")
@app.route('/replydoubt2',methods=['post'])
def replydoubt2():
    dt=request.form['textarea']

    qry="UPDATE `doubt` SET `reply`=%s WHERE `did`=%s"
    iud(qry,(dt,session['did']))

    return '''<script>alert("send successfully");window.location='/viewdoubt'</script>'''



@app.route('/sendtips')
def sendtips():
    return render_template("expert/send_tips.html")


@app.route('/sendtips1',methods=['post'])
def sendtips1():
    tip=request.form['textarea']
    qry="INSERT INTO `tips` VALUES(NULL,%s,%s,CURDATE())"
    val=(session['lid'],tip)
    iud(qry,val)
    return '''<script>alert("send successfully");window.location='/addtips'</script>'''



@app.route('/viewdoubt')
def viewdoubt():
    qry="SELECT`user`.`firstname`,`lastname`,`doubt`.*FROM`doubt` JOIN `user`ON `doubt`.`lid`=`user`.`lid` WHERE `doubt`.`eid`=%s"
    res=selectall2(qry,session['lid'])

    return render_template("expert/view_doubt.html",val=res)


@app.route('/askdoubt')
def askdoubt():
    q="select * from expert"
    res=selectall(q)
    return render_template("user/ask_doubt.html",val=res)

@app.route('/senddoubt')
def senddoubt():
    id=request.args.get('id')
    session['expid']=id
    return render_template("user/send_doubt.html")

@app.route('/senddoubt_post',methods=['post'])
def senddoubt_post():
    doubt=request.form['textarea']
    exid=session['expid']
    q="INSERT INTO `doubt` VALUES (NULL,%s,%s,%s,'pending',CURDATE())"
    val=(session['lid'],exid,doubt)
    iud(q,val)
    return '''<script>alert("send successfully");window.location='/replydoubt'</script>'''

#=================USER===========

@app.route('/user_home')
def user_home():
    return render_template("user/home.html")

@app.route('/signup')
def signup():
    return render_template("regiindex.html")

@app.route('/signup1',methods=['post'])
def signup1():
    fname=request.form['textfield']
    lname=request.form['textfield2']
    place=request.form['textfield3']
    post=request.form['textfield4']
    pin=request.form['textfield5']
    phone=request.form['textfield6']
    email=request.form['textfield7']
    uname=request.form['textfield10']
    pword=request.form['textfield11']

    qry="INSERT INTO `login` VALUES (NULL,%s,%s,'user')"
    val=(uname,pword)
    res=iud(qry,val)

    q="INSERT INTO `user` VALUES (NULL,%s,%s,%s,%s,%s,%s,%s,%s)"
    val1=(str(res),fname,lname,place,post,pin,phone,email)
    iud(q,val1)
    return '''<script>alert("SUCESSFULLY LOGIN");window.location="/"</script>'''

@app.route('/block')
def block():
    id=request.args.get('id')
    qry="UPDATE `login` SET `type`='blocked' WHERE `login_id`=%s"
    iud(qry,id)
    return '''<script>alert("Blocked This User");window.location="/blockunblock"</script>'''


@app.route('/unblock')
def unblock():
    id=request.args.get('id')
    qry="UPDATE `login` SET `type`='user' WHERE `login_id`=%s"
    iud(qry,id)
    return '''<script>alert("UNBLCKED THIS USER");window.location="/blockunblock"</script>'''

@app.route('/predict')
def predict():
    return render_template("user/predict.html")


@app.route('/replydoubt')
def replydoubt():
    q = "SELECT * FROM `doubt` JOIN `expert`ON `doubt`.`eid`=`expert`.`lid` WHERE doubt.`lid`=%s"
    res = selectall2(q, session['lid'])

    return render_template("user/reply_doubt.html",data=res)

@app.route('/result')
def result():
    return render_template("user/result.html")

@app.route('/sendcomplaint')
def sendcomplaint():
    return render_template("user/send_complaint.html")

@app.route('/complaint')
def complaint():
    qry="SELECT*FROM`complaint`"
    res=selectall(qry)
    return render_template("user/view_complaint.html" ,data=res)




@app.route('/scomplaint1',methods=['post'])
def complaint1():
    cmplnt=request.form['textarea']
    qry="INSERT INTO `complaint` VALUES (NULL,%s,%s,curdate(),'pending')"
    val=(session['lid'],cmplnt)
    iud(qry,val)
    return '''<script>alert("SUCESSFULLY SEND");window.location="/complaint"</script>'''



@app.route('/notifications')
def notifications():
    qry="SELECT*FROM`notification`"
    res=selectall(qry)
    return render_template("user/view_notifications.html",data=res)



@app.route('/tips')
def tips():
    qry="SELECT*FROM`tips`"
    res=selectall(qry)
    return render_template("user/view_tips.html",data=res)



app.run(debug=True)
