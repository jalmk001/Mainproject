/*
SQLyog Community v13.0.1 (64 bit)
MySQL - 10.4.27-MariaDB : Database - pcos
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`pcos` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `pcos`;

/*Table structure for table `complaint` */

DROP TABLE IF EXISTS `complaint`;

CREATE TABLE `complaint` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `complaint` varchar(100) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `reply` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `complaint` */

insert  into `complaint`(`cid`,`lid`,`complaint`,`date`,`reply`) values 
(1,3,'hjjhhhhh','f4455','jgfdzxcvnmbvcxcz '),
(2,3,'jalva good vibes','2023-08-28','jalva pavama'),
(3,41,'okd\r\n','2023-03-25','it\'s okay'),
(4,41,'okd\r\n','2023-03-25','pending'),
(5,41,'hih','2023-03-25','pending'),
(6,41,'hih','2023-03-25','pending'),
(7,41,'jalu saf','2023-03-25','pending'),
(8,41,'hello girl','2023-03-25','pending'),
(9,41,'management is not good','2023-03-26','pending'),
(10,41,'management is not good','2023-03-26','pending');

/*Table structure for table `doubt` */

DROP TABLE IF EXISTS `doubt`;

CREATE TABLE `doubt` (
  `did` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `eid` int(11) DEFAULT NULL,
  `doubt` varchar(50) DEFAULT NULL,
  `reply` text DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`did`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `doubt` */

insert  into `doubt`(`did`,`lid`,`eid`,`doubt`,`reply`,`date`) values 
(1,41,40,'asdf','pending','2023-03-25'),
(2,41,40,'dfdfgfg','pending','2023-03-26'),
(3,41,40,'lkjhgv','pending','2023-03-26'),
(4,41,40,'jhghhbnvvvv','pending','2023-03-26'),
(5,41,42,'dr is summa cute','jjj','2023-03-26'),
(6,41,42,'can you','pending','2023-03-26');

/*Table structure for table `expert` */

DROP TABLE IF EXISTS `expert`;

CREATE TABLE `expert` (
  `eid` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `place` varchar(50) DEFAULT NULL,
  `post` varchar(50) DEFAULT NULL,
  `pin` int(11) DEFAULT NULL,
  `phone` bigint(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `qualification` varchar(50) DEFAULT NULL,
  `image` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`eid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `expert` */

insert  into `expert`(`eid`,`lid`,`firstname`,`lastname`,`place`,`post`,`pin`,`phone`,`email`,`qualification`,`image`) values 
(6,40,'MOHAMMED MK','jalva','kkk','kkllk',679571,918138044972,'jalvajebin001@gmail.com','mca','2016-12-08-20-50-03-904.jpg'),
(7,42,'kiran','kailas','guruvayoor','thrissur',69571,918138044972,'jalvajebin001@gmail.com','gynac','20191105_182214.jpg');

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `login` */

insert  into `login`(`login_id`,`username`,`password`,`type`) values 
(1,'admin','admin','admin'),
(3,'jalva','12345','blocked'),
(40,'jalva','123456','expert'),
(41,'akhila','akhila','user'),
(42,'kiranmk','kiran','expert'),
(43,'jalva','#Jaljal123','user');

/*Table structure for table `notification` */

DROP TABLE IF EXISTS `notification`;

CREATE TABLE `notification` (
  `nid` int(11) NOT NULL AUTO_INCREMENT,
  `notification` varchar(100) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`nid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `notification` */

insert  into `notification`(`nid`,`notification`,`date`) values 
(3,'notfn','2023-03-17'),
(6,'the monthly plan updated','2023-03-26');

/*Table structure for table `tips` */

DROP TABLE IF EXISTS `tips`;

CREATE TABLE `tips` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `eid` int(11) DEFAULT NULL,
  `tips` varchar(100) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tips` */

insert  into `tips`(`tid`,`eid`,`tips`,`date`) values 
(3,3,'c cbbxzcbxncbxzb','2023-03-26'),
(5,42,'good job','2023-03-26');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `place` varchar(50) DEFAULT NULL,
  `post` varchar(50) DEFAULT NULL,
  `pin` int(11) DEFAULT NULL,
  `phone` bigint(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `user` */

insert  into `user`(`uid`,`lid`,`firstname`,`lastname`,`place`,`post`,`pin`,`phone`,`email`) values 
(1,3,'jalva','jebin','kkk','lll',66868,918138044972,'jalvajebin001@gmail.com'),
(2,41,'akhilA','AKATHAN','PATHARANGADI','PATHARANGDI',676306,9898989898,'AKHILAREGIONAL@gmail.com'),
(3,43,'kiran','kailas','kuttippuram','ddd',679571,8138044972,'jalvajebin001@gmail.com');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
